"use client";

import { useState, useRef, useEffect, useCallback } from "react";

const SEEING = [
  "Reading between your words",
  "Finding the shape of your perspective",
  "Looking for what you can't see",
  "Locating the blind spot",
];

export default function MirrorPage() {
  const [phase, setPhase] = useState("landing");
  const [text, setText] = useState("");
  const [question, setQuestion] = useState("");
  const [error, setError] = useState("");
  const [vis, setVis] = useState(false);
  const [qVis, setQVis] = useState(false);
  const [sIdx, setSIdx] = useState(0);
  const [sFade, setSFade] = useState(true);
  const taRef = useRef(null);
  const sTimer = useRef(null);

  useEffect(() => {
    setTimeout(() => setVis(true), 80);
  }, []);

  useEffect(() => {
    if (phase !== "processing") {
      clearInterval(sTimer.current);
      return;
    }
    sTimer.current = setInterval(() => {
      setSFade(false);
      setTimeout(() => {
        setSIdx((i) => (i + 1) % SEEING.length);
        setSFade(true);
      }, 400);
    }, 2800);
    return () => clearInterval(sTimer.current);
  }, [phase]);

  const goTo = useCallback((next, d = 500) => {
    setVis(false);
    setTimeout(() => {
      setPhase(next);
      setTimeout(() => setVis(true), 60);
      if (next === "input") setTimeout(() => taRef.current?.focus(), 350);
    }, d);
  }, []);

  const submit = useCallback(async () => {
    if (text.trim().length < 20) return;
    goTo("processing", 500);

    try {
      const res = await fetch("/api/mirror", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: text.trim() }),
      });

      const data = await res.json();

      if (!res.ok || !data.question) {
        throw new Error(data.error || "No reflection");
      }

      setQuestion(data.question);
      setVis(false);
      setTimeout(() => {
        setPhase("question");
        setTimeout(() => setQVis(true), 120);
      }, 700);
    } catch (e) {
      setError(e.message || "The reflection broke. Try again.");
      goTo("error", 400);
    }
  }, [text, goTo]);

  const reset = useCallback(() => {
    setQVis(false);
    setTimeout(() => {
      setText("");
      setQuestion("");
      setError("");
      setSIdx(0);
      goTo("landing", 400);
    }, 500);
  }, [goTo]);

  const onKey = (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      submit();
    }
  };

  const ok = text.trim().length >= 20;

  return (
    <main className="mirror-root">
      {/* Atmospheric layers */}
      <div className="noise" />
      <div className="vignette" />
      <div className="center-glow" />

      {/* ═══ LANDING ═══ */}
      {phase === "landing" && (
        <div className="content" style={{ opacity: vis ? 1 : 0 }}>
          <div className="ring">
            <div className="ring-dot" />
          </div>
          <h1 className="title">The Mirror</h1>
          <div className="divider" />
          <p className="tagline">Tell me what you&apos;re carrying right now.</p>
          <p className="tag-sub">
            I won&apos;t help you. I&apos;ll ask you the one question
            <br />
            you&apos;re not asking yourself.
          </p>
          <button className="cta" onClick={() => goTo("input")}>
            I&apos;m ready
          </button>
        </div>
      )}

      {/* ═══ INPUT ═══ */}
      {phase === "input" && (
        <div className="content" style={{ opacity: vis ? 1 : 0 }}>
          <p className="prompt">
            What&apos;s the situation, the decision, the thing weighing on you?
          </p>
          <p className="prompt-sub">
            Don&apos;t organize it. Don&apos;t make it make sense. Just say it.
          </p>
          <div className="ta-wrap">
            <textarea
              ref={taRef}
              className="textarea"
              value={text}
              onChange={(e) => setText(e.target.value)}
              onKeyDown={onKey}
              placeholder="Start typing..."
              maxLength={3000}
              rows={7}
            />
            {text.length > 0 && (
              <span className="char-count">{text.length}/3000</span>
            )}
          </div>
          <button
            className="submit-btn"
            style={{
              opacity: ok ? 1 : 0.15,
              cursor: ok ? "pointer" : "default",
            }}
            onClick={submit}
            disabled={!ok}
          >
            Show me what I can&apos;t see
          </button>
          {text.length > 0 && text.trim().length < 20 && (
            <p className="hint">Say a little more...</p>
          )}
        </div>
      )}

      {/* ═══ PROCESSING ═══ */}
      {phase === "processing" && (
        <div className="content" style={{ opacity: vis ? 1 : 0 }}>
          <div className="pulse-wrap">
            <div className="pulse-dot" />
            <div className="pulse-ring-1" />
            <div className="pulse-ring-2" />
          </div>
          <p
            className="seeing-text"
            style={{ opacity: sFade ? 1 : 0 }}
          >
            {SEEING[sIdx]}
          </p>
        </div>
      )}

      {/* ═══ THE QUESTION ═══ */}
      {phase === "question" && (
        <div
          className="content question-phase"
          style={{ opacity: qVis ? 1 : 0 }}
        >
          <div className="q-wrap">
            <span className="q-deco">&ldquo;</span>
            <p className="q-text">{question}</p>
          </div>
          <div className="q-actions">
            <button className="restart-btn" onClick={reset}>
              Start over
            </button>
          </div>
          <p className="credit">The Mirror&ensp;—&ensp;MachineMind</p>
        </div>
      )}

      {/* ═══ ERROR ═══ */}
      {phase === "error" && (
        <div className="content" style={{ opacity: vis ? 1 : 0 }}>
          <p className="error-text">{error}</p>
          <button className="restart-btn" onClick={reset}>
            Try again
          </button>
        </div>
      )}

      <style jsx>{`
        .mirror-root {
          min-height: 100vh;
          width: 100%;
          background: #060606;
          display: flex;
          align-items: center;
          justify-content: center;
          position: relative;
          overflow: hidden;
        }

        .noise {
          position: fixed;
          inset: 0;
          background: url("data:image/svg+xml,%3Csvg viewBox='0 0 512 512' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.85' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='0.025'/%3E%3C/svg%3E");
          animation: grainAnim 6s steps(8) infinite;
          pointer-events: none;
          z-index: 1;
        }

        .vignette {
          position: fixed;
          inset: 0;
          background: radial-gradient(ellipse at 50% 50%, transparent 30%, rgba(0,0,0,0.7) 100%);
          pointer-events: none;
          z-index: 2;
        }

        .center-glow {
          position: fixed;
          top: 50%;
          left: 50%;
          width: 600px;
          height: 600px;
          transform: translate(-50%, -50%);
          background: radial-gradient(circle, rgba(255,255,255,0.012) 0%, transparent 70%);
          pointer-events: none;
          z-index: 2;
        }

        .content {
          position: relative;
          z-index: 10;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          text-align: center;
          padding: 40px 28px;
          max-width: 620px;
          width: 100%;
          transition: opacity 0.8s ease;
        }

        .question-phase {
          transition: opacity 2s cubic-bezier(0.25, 0.1, 0.25, 1);
        }

        /* ── Landing ── */
        .ring {
          width: 64px;
          height: 64px;
          border-radius: 50%;
          border: 1px solid rgba(255,255,255,0.06);
          display: flex;
          align-items: center;
          justify-content: center;
          margin-bottom: 36px;
          animation: spin 30s linear infinite;
        }

        .ring-dot {
          width: 6px;
          height: 6px;
          border-radius: 50%;
          background: rgba(255,255,255,0.25);
          animation: breathe 3s ease-in-out infinite;
        }

        .title {
          font-family: 'Playfair Display', serif;
          font-size: clamp(48px, 10vw, 80px);
          font-weight: 300;
          color: #fff;
          letter-spacing: 0.04em;
          line-height: 1;
          margin-bottom: 24px;
        }

        .divider {
          width: 40px;
          height: 1px;
          background: rgba(255,255,255,0.12);
          margin-bottom: 28px;
        }

        .tagline {
          font-size: 17px;
          font-weight: 200;
          color: rgba(255,255,255,0.55);
          line-height: 1.7;
          margin-bottom: 10px;
          letter-spacing: 0.015em;
        }

        .tag-sub {
          font-size: 13.5px;
          font-weight: 200;
          color: rgba(255,255,255,0.28);
          line-height: 1.9;
          margin-bottom: 48px;
        }

        .cta {
          background: transparent;
          border: 1px solid rgba(255,255,255,0.12);
          color: rgba(255,255,255,0.6);
          font-family: 'Outfit', sans-serif;
          font-size: 13px;
          font-weight: 300;
          letter-spacing: 0.18em;
          text-transform: uppercase;
          padding: 15px 56px;
          cursor: pointer;
        }

        /* ── Input ── */
        .prompt {
          font-family: 'Playfair Display', serif;
          font-size: clamp(20px, 4vw, 26px);
          font-weight: 300;
          font-style: italic;
          color: rgba(255,255,255,0.7);
          line-height: 1.55;
          margin-bottom: 10px;
        }

        .prompt-sub {
          font-size: 13px;
          font-weight: 200;
          color: rgba(255,255,255,0.22);
          margin-bottom: 32px;
          letter-spacing: 0.01em;
        }

        .ta-wrap {
          width: 100%;
          position: relative;
          margin-bottom: 28px;
        }

        .textarea {
          width: 100%;
          min-height: 180px;
          background: rgba(255,255,255,0.02);
          border: 1px solid rgba(255,255,255,0.06);
          border-radius: 3px;
          color: rgba(255,255,255,0.85);
          font-family: 'Outfit', sans-serif;
          font-size: 15px;
          font-weight: 200;
          line-height: 1.85;
          padding: 22px;
          resize: vertical;
          letter-spacing: 0.005em;
          transition: border-color 0.4s ease;
        }

        .char-count {
          position: absolute;
          bottom: 10px;
          right: 14px;
          font-size: 11px;
          font-weight: 300;
          color: rgba(255,255,255,0.15);
        }

        .submit-btn {
          background: transparent;
          border: 1px solid rgba(255,255,255,0.15);
          color: rgba(255,255,255,0.65);
          font-family: 'Playfair Display', serif;
          font-size: 14px;
          font-weight: 400;
          font-style: italic;
          letter-spacing: 0.06em;
          padding: 15px 44px;
          cursor: pointer;
          transition: all 0.4s ease;
        }

        .hint {
          font-size: 12px;
          font-weight: 200;
          color: rgba(255,255,255,0.2);
          margin-top: 14px;
        }

        /* ── Processing ── */
        .pulse-wrap {
          position: relative;
          width: 20px;
          height: 20px;
          margin-bottom: 40px;
        }

        .pulse-dot {
          position: absolute;
          inset: 0;
          border-radius: 50%;
          background: rgba(255,255,255,0.2);
          animation: breathe 2.5s ease-in-out infinite;
        }

        .pulse-ring-1 {
          position: absolute;
          top: 50%;
          left: 50%;
          width: 20px;
          height: 20px;
          margin-top: -10px;
          margin-left: -10px;
          border-radius: 50%;
          border: 1px solid rgba(255,255,255,0.08);
          animation: p1 2.5s ease-out infinite;
        }

        .pulse-ring-2 {
          position: absolute;
          top: 50%;
          left: 50%;
          width: 20px;
          height: 20px;
          margin-top: -10px;
          margin-left: -10px;
          border-radius: 50%;
          border: 1px solid rgba(255,255,255,0.05);
          animation: p2 3.2s ease-out infinite;
          animation-delay: 0.8s;
        }

        .seeing-text {
          font-size: 13px;
          font-weight: 200;
          color: rgba(255,255,255,0.25);
          letter-spacing: 0.12em;
          text-transform: lowercase;
          transition: opacity 0.4s ease;
        }

        /* ── Question ── */
        .q-wrap {
          max-width: 540px;
          position: relative;
          padding: 0 16px;
        }

        .q-deco {
          font-family: 'Playfair Display', serif;
          font-size: 140px;
          font-weight: 300;
          color: rgba(255,255,255,0.03);
          line-height: 1;
          display: block;
          margin-bottom: -50px;
          user-select: none;
        }

        .q-text {
          font-family: 'Playfair Display', serif;
          font-size: clamp(22px, 5vw, 34px);
          font-weight: 300;
          font-style: italic;
          color: rgba(255,255,255,0.92);
          line-height: 1.65;
          letter-spacing: 0.005em;
        }

        .q-actions {
          margin-top: 60px;
          display: flex;
          gap: 20px;
          align-items: center;
        }

        .restart-btn {
          background: transparent;
          border: 1px solid rgba(255,255,255,0.08);
          color: rgba(255,255,255,0.3);
          font-family: 'Outfit', sans-serif;
          font-size: 11px;
          font-weight: 300;
          letter-spacing: 0.14em;
          text-transform: uppercase;
          padding: 10px 32px;
          cursor: pointer;
        }

        .credit {
          font-size: 10px;
          font-weight: 200;
          color: rgba(255,255,255,0.1);
          margin-top: 52px;
          letter-spacing: 0.2em;
          text-transform: uppercase;
        }

        .error-text {
          font-size: 14px;
          font-weight: 200;
          color: rgba(255,180,180,0.5);
          margin-bottom: 24px;
        }
      `}</style>
    </main>
  );
}
