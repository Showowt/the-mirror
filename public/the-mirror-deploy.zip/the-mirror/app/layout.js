import "./globals.css";

export const metadata = {
  title: "The Mirror — by MachineMind",
  description: "I won't help you. I'll ask you the one question you're not asking yourself.",
  openGraph: {
    title: "The Mirror",
    description: "I won't help you. I'll ask you the one question you're not asking yourself.",
    type: "website",
    siteName: "The Mirror by MachineMind",
    images: [{ url: "/og.png", width: 1200, height: 630, alt: "The Mirror — by MachineMind" }],
  },
  twitter: {
    card: "summary_large_image",
    title: "The Mirror",
    description: "I won't help you. I'll ask you the one question you're not asking yourself.",
    images: ["/og.png"],
    creator: "@showowt",
  },
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <head>
        <link
          href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,300;0,400;1,300;1,400&family=Outfit:wght@200;300;400&display=swap"
          rel="stylesheet"
        />
      </head>
      <body>{children}</body>
    </html>
  );
}
