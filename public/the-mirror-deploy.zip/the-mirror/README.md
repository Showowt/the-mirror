# THE MIRROR — by MachineMind

> I won't help you. I'll ask you the one question you're not asking yourself.

## Deploy to Vercel (5 minutes)

### Option A: GitHub → Vercel (recommended)

1. Push this folder to a new GitHub repo:
   ```bash
   cd the-mirror
   git init
   git add .
   git commit -m "The Mirror — launch"
   git remote add origin https://github.com/YOUR_USERNAME/the-mirror.git
   git push -u origin main
   ```

2. Go to [vercel.com/new](https://vercel.com/new)

3. Import your `the-mirror` repo

4. Add environment variable:
   - Key: `ANTHROPIC_API_KEY`
   - Value: your Anthropic API key

5. Click **Deploy**

6. Your Mirror is live.

### Option B: Vercel CLI

```bash
cd the-mirror
npm install
npx vercel --prod
# When prompted, add ANTHROPIC_API_KEY as an environment variable
```

## Custom Domain

After deployment, go to your Vercel project settings → Domains → Add `themirror.ai` or whatever domain you want.

## Stack

- **Frontend**: Next.js 14 (App Router)
- **Backend**: Next.js API Route → Anthropic Claude API
- **Styling**: CSS-in-JSX (zero dependencies)
- **Fonts**: Playfair Display + Outfit (Google Fonts)
- **AI**: Claude Sonnet 4 with custom Mirror system prompt

## Architecture

```
the-mirror/
├── app/
│   ├── layout.js          # Root layout + OG meta tags
│   ├── page.js            # The Mirror UI (client component)
│   ├── globals.css         # Animations + base styles
│   └── api/
│       └── mirror/
│           └── route.js   # THE WEAPON — system prompt + API call
├── package.json
├── next.config.js
└── .env.example
```

The system prompt in `route.js` is the core IP. It layers:
- **Blind Spot Protocol** — finds what's structurally invisible from the user's perspective
- **Inversion Protocol** — asks the question the user is avoiding
- **APEX Metacognition** — models the shape of the user's seeing, not just what they said

## Cost

~$0.01-0.03 per mirror interaction (one API call to Claude Sonnet).
At 100K users/day: ~$1,000-3,000/day in API costs.
